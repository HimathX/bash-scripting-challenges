#!/bin/bash
echo "$1"|tr a-zA-Z n-za-mN-ZA-M
