#!/bin/bash
python3 ./src/oracle.py $1