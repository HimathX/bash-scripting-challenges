#!/bin/bash
grep -rwo $1 src|wc -l